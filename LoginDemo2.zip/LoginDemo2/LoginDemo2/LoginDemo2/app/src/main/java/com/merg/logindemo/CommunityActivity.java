package com.merg.logindemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;

public class CommunityActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_community);
        TextView t = (TextView)findViewById(R.id.textView4);
        t.setMovementMethod(LinkMovementMethod.getInstance());
    }
}
