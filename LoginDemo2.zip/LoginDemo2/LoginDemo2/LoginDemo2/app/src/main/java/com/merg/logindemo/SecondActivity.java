package com.merg.logindemo;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class SecondActivity extends AppCompatActivity {

    private FirebaseAuth firebaseAuth;
    private Button logout;
    CalendarView calendarView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        firebaseAuth = FirebaseAuth.getInstance();

    calendarView = (CalendarView)findViewById(R.id.calendarView);


    calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
        @Override
        public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
            String date = (dayOfMonth) + "/" + (month + 1) + "/" + year;

        }
    });

    }


    private void Logout(){
        firebaseAuth.signOut();
        finish();
        startActivity(new Intent(SecondActivity.this, MainActivity.class));
    }

    private void gotoEvents(){
        startActivity(new Intent(SecondActivity.this, EventsActivity.class));
    }

    private void gotoMaps(){
        startActivity(new Intent(SecondActivity.this, MapActivity.class));
    }

    private void gotoCommunity(){
        startActivity(new Intent(SecondActivity.this, CommunityActivity.class));
    }

    private void gotoFaq(){
        startActivity(new Intent(SecondActivity.this, faqActivity.class));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

            if (item.getItemId() == R.id.logoutMenu) {
                Logout();
            } else if (item.getItemId() == R.id.eventsMenu){
                gotoEvents();
            } else if (item.getItemId() == R.id.mapsMenu){
                gotoMaps();
            } else if (item.getItemId() == R.id.communityMenu){
                gotoCommunity();
            } else if (item.getItemId() == R.id.faqMenu){
                gotoFaq();;
            }
            return false;

     /*   switch (item.getItemId()){
            case R.id.logoutMenu:{
                Logout();
            }
            case R.id.eventsMenu:{
                gotoEvents();
            }
            case R.id.mapsMenu:{
                gotoMaps();
            }
            case R.id.communityMenu:{
                gotoCommunity();
            }
            case R.id.faqMenu:{
                gotoFaq();
            }
        }
        return super.onOptionsItemSelected(item); */
    }
}
